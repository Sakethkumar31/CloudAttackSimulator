import time
from caldera_client import get_agents, get_links
from neo4j_writer import write_agent, write_fact
from config import SYNC_INTERVAL

print("[+] Caldera → Neo4j Phase-2 sync started")

while True:
    try:
        # -------- AGENTS (CONTEXT) --------
        agents = get_agents()
        agent_map = {a["paw"]: a for a in agents}

        for agent in agents:
            write_agent(agent)

        # -------- LINKS (EXECUTION TRUTH) --------
        links = get_links()

        ingested = 0

        for link in links:
            # HARD EXECUTION GATE
            if link.get("status") not in ("success", "failure"):
                continue
            if not link.get("command"):
                continue
            if not link.get("paw"):
                continue
            if not link.get("finish"):
                continue

            # FACTS ONLY FROM EXECUTED LINKS
            for fact in link.get("facts", []):
                trait = fact.get("trait")
                value = fact.get("value")

                if not trait or not value:
                    continue

                write_fact({
                    "trait": trait,
                    "value": value,
                    "source": "caldera-link"
                })
                ingested += 1

        print(f"[✓] Synced {len(agents)} agents, {ingested} executed facts")

    except Exception as e:
        print("[!] Sync error:", e)

    time.sleep(SYNC_INTERVAL)
