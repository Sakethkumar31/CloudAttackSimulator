from neo4j import GraphDatabase
from config import NEO4J_URI, NEO4J_USER, NEO4J_PASSWORD

driver = GraphDatabase.driver(
    NEO4J_URI,
    auth=(NEO4J_USER, NEO4J_PASSWORD)
)

def write_agent(agent):
    query = """
    MERGE (a:Agent {id: $id})
    SET a.host = $host,
        a.platform = $platform,
        a.group = $group,
        a.last_seen = datetime($last_seen)
    """
    with driver.session() as session:
        session.run(
            query,
            id=agent["paw"],
            host=agent.get("host"),
            platform=agent.get("platform"),
            group=agent.get("group"),
            last_seen=agent.get("last_seen")
        )

def write_fact(fact):
    query = """
    MERGE (f:Fact {trait: $trait, value: $value})
    SET f.source = $source
    """
    with driver.session() as session:
        session.run(
            query,
            trait=fact["trait"],
            value=fact["value"],
            source=fact.get("source")
        )
