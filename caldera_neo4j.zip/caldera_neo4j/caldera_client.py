import requests
from config import CALDERA_URL, CALDERA_API_KEY

HEADERS = {"KEY": CALDERA_API_KEY}

def get_agents():
    r = requests.get(f"{CALDERA_URL}/api/v2/agents", headers=HEADERS)
    r.raise_for_status()
    return r.json()

def get_links():
    r = requests.get(f"{CALDERA_URL}/api/v2/links", headers=HEADERS)
    r.raise_for_status()
    return r.json()
