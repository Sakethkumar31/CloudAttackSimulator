from flask import Flask, request, redirect, session, render_template_string

app = Flask(__name__)
app.secret_key = "ctf_secret_key"

# ======================
# CONFIGURATION
# ======================
FLAG = "ctf{hi}"
POINTS = 100
scores = {}

# ======================
# RED DRAMATIC THEME
# ======================
BASE_STYLE = """
<style>
:root {
    --bg-main: #0e0e0e;
    --panel-bg: #161212;
    --border-soft: #2a1a1a;
    --red-accent: #b33a3a;
    --red-muted: #8f2d2d;
    --text-main: #e6e6e6;
    --text-muted: #b8a5a5;
    --success: #4caf50;
    --error: #e57373;
}

body {
    margin: 0;
    font-family: "Segoe UI", system-ui, -apple-system, BlinkMacSystemFont, sans-serif;
    background: linear-gradient(180deg, #120909, var(--bg-main));
    color: var(--text-main);
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
}

/* Main container */
.card {
    background: var(--panel-bg);
    padding: 28px 30px;
    border-radius: 10px;
    width: 420px;
    border: 1px solid var(--border-soft);
}

/* Title */
h2 {
    margin: 0 0 16px;
    text-align: center;
    font-size: 20px;
    font-weight: 600;
    color: var(--red-accent);
    letter-spacing: 0.5px;
}

/* Paragraph text */
p {
    margin: 8px 0;
    font-size: 14.5px;
    color: var(--text-muted);
    line-height: 1.5;
}

/* Inputs */
input {
    width: 100%;
    padding: 12px;
    margin-top: 14px;
    border-radius: 6px;
    border: 1px solid var(--border-soft);
    background: #0f0c0c;
    color: var(--text-main);
    font-size: 14px;
}

input::placeholder {
    color: #8a6b6b;
}

input:focus {
    outline: none;
    border-color: var(--red-muted);
}

/* Buttons */
button {
    width: 100%;
    padding: 12px;
    margin-top: 16px;
    background: var(--red-accent);
    border: none;
    border-radius: 6px;
    color: #ffffff;
    font-weight: 600;
    font-size: 14px;
    cursor: pointer;
}

button:hover {
    background: var(--red-muted);
}

/* Messages */
.success {
    margin-top: 14px;
    color: var(--success);
    font-weight: 600;
}

.error {
    margin-top: 14px;
    color: var(--error);
    font-weight: 600;
}

/* Score */
.score {
    margin-top: 12px;
    font-size: 15px;
    color: var(--text-main);
}

/* Links */
a {
    display: inline-block;
    margin-top: 10px;
    color: var(--red-accent);
    text-decoration: none;
    font-weight: 600;
}

a:hover {
    text-decoration: underline;
}

/* Scoreboard table */
table {
    width: 100%;
    margin-top: 14px;
    border-collapse: collapse;
    font-size: 14px;
}

th {
    text-align: left;
    padding: 8px 6px;
    color: var(--red-accent);
    border-bottom: 1px solid var(--border-soft);
}

td {
    padding: 8px 6px;
    color: var(--text-main);
    border-bottom: 1px solid #241414;
}
</style>
"""


# ======================
# HTML PAGES
# ======================
LOGIN_PAGE = BASE_STYLE + """
<div class="card">
<h2>⚠️ CTF ACCESS TERMINAL ⚠️</h2>
<form method="post">
  <input name="username" placeholder="Enter Codename" required>
  <button type="submit">LOGIN</button>
</form>
</div>
"""

CHALLENGE_PAGE = BASE_STYLE + """
<div class="card">
<h2>WELCOME {{ user }}</h2>

<p><b>Challenge:</b> A word we say when we meet someone we know.</p>

<form method="post" action="/submit">
  <input name="flag" placeholder="Enter Flag (ctf{...})">
  <button type="submit">SUBMIT FLAG</button>
</form>

<p class="{{ 'success' if success else 'error' }}">{{ message }}</p>

<p class="score">Your Score: {{ score }}</p>
<p style=color:off-white;font-weight::bold;text-decoration:underline;font-style:Italic;>Note:Flag-ctf{.........}.<p>
<a href="/scoreboard">View Scoreboard</a><br><br>
<a href="/logout">Logout</a>
</div>
"""

SCOREBOARD_PAGE = BASE_STYLE + """
<div class="card">
<h2>🏆 SCOREBOARD</h2>

<table>
<tr><th>Player</th><th>Score</th></tr>
{% for user, score in scores %}
<tr><td>{{ user }}</td><td>{{ score }}</td></tr>
{% endfor %}
</table>

<br>
<a href="/challenge">Back to Challenge</a>
</div>
"""

# ======================
# ROUTES
# ======================
@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        user = request.form['username']
        session['user'] = user
        scores.setdefault(user, 0)
        return redirect('/challenge')
    return LOGIN_PAGE

@app.route('/challenge')
def challenge():
    if 'user' not in session:
        return redirect('/')
    user = session['user']
    return render_template_string(
        CHALLENGE_PAGE,
        user=user,
        score=scores[user],
        message="",
        success=False
    )

@app.route('/submit', methods=['POST'])
def submit():
    if 'user' not in session:
        return redirect('/')
    user = session['user']
    submitted_flag = request.form['flag']

    if submitted_flag == FLAG:
        scores[user] = POINTS
        message = "🏁 FLAG CAPTURED!"
        success = True
    else:
        message = "❌ INCORRECT FLAG"
        success = False

    return render_template_string(
        CHALLENGE_PAGE,
        user=user,
        score=scores[user],
        message=message,
        success=success
    )

@app.route('/scoreboard')
def scoreboard():
    sorted_scores = sorted(scores.items(), key=lambda x: x[1], reverse=True)
    return render_template_string(
        SCOREBOARD_PAGE,
        scores=sorted_scores
    )

@app.route('/logout')
def logout():
    session.clear()
    return redirect('/')

# ======================
# RUN SERVER
# ======================
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
